package ru.V5Minecraft.FakeTNTMod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import ru.V5Minecraft.FakeTNTMod.Primed.EntityLoader;
import ru.V5Minecraft.FakeTNTMod.Proxy.CommonProxy;

@Mod(modid = "faketntmod", name = "FakeTNTMod", version = "1.4")
public class FakeTNTMod {
    @Mod.Instance("faketntmod")
    public static FakeTNTMod instance;
    @SidedProxy(clientSide = "ru.V5Minecraft.FakeTNTMod.Proxy.ClientProxy", serverSide = "ru.V5Minecraft.FakeTNTMod.Proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        proxy.preInit(event);
        EntityLoader.init();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }

    @EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        proxy.postInit(event);
    }
}
