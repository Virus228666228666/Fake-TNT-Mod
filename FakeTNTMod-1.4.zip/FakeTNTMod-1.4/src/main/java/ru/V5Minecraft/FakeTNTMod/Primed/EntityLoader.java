package ru.V5Minecraft.FakeTNTMod.Primed;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import ru.V5Minecraft.FakeTNTMod.FakeTNTMod;

public class EntityLoader {
   private static int id = 0;

   public static void init() {
      registerNoEgg(EntityFakeTNTPrimed.class, "blockfaketnt");
   }

   public static void register(Class EntityClass, String entityNameIn, int solidColorIn, int spotColorIn) {
      EntityRegistry.registerModEntity(new ResourceLocation("faketntmod:" + entityNameIn), EntityClass, entityNameIn, ++id, FakeTNTMod.instance, 64, 1, true, solidColorIn, spotColorIn);
      RegisterSpawn();
   }

   public static void registerNoEgg(Class EntityClass, String entityNameIn) {
      EntityRegistry.registerModEntity(new ResourceLocation("faketntmod:" + entityNameIn), EntityClass, entityNameIn, ++id, FakeTNTMod.instance, 64, 1, true);
   }

   public static void RegisterSpawn() {}
}
